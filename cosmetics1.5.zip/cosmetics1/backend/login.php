<?php
session_start();
$conn = new mysqli("localhost","root","","cosmetics_db");
include("../db.php");
// ✅ CHECK FORM SUBMIT
if(isset($_POST['email']) && isset($_POST['password'])){

    $email = $_POST['email'];
    $password = $_POST['password'];

    $result = $conn->query("SELECT * FROM users WHERE email='$email' AND password='$password'");

    if($result->num_rows > 0){

        $user = $result->fetch_assoc();

        // ✅ SESSION SET
        $_SESSION['user_id'] = $user['id'];

        header("Location: ../index.php");
        exit();

    } else {
        echo "<script>alert('Invalid Login'); window.location.href='login.html';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Login</title>

<style>
body{
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#667eea,#764ba2);
    font-family:Arial;
}

.login-box{
    background:rgba(255,255,255,0.15);
    padding:30px;
    border-radius:15px;
    color:white;
    width:300px;
    text-align:center;
}

input{
    width:100%;
    padding:10px;
    margin:10px 0;
    border:none;
    border-radius:8px;
}

button{
    width:100%;
    padding:10px;
    border:none;
    background:white;
    cursor:pointer;
}
</style>
</head>

<body>

<div class="login-box">
<h2>Login</h2>

<form method="POST">
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>

<button type="submit" name="login">Login</button>
</form>

</div>

</body>
</html>