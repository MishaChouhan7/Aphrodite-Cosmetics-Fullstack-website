<?php
session_start();

// ✅ Check admin login
if (!isset($_SESSION['admin'])) {
    echo "Access denied";
    exit;
}

$conn = new mysqli("localhost", "root", "", "cosmetics_db");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = $_POST['name'];
    $price = $_POST['price'];

    // 🔥 IMAGE UPLOAD START
    $imageName = $_FILES['image']['name'];
    $tmpName = $_FILES['image']['tmp_name'];

    $uploadPath = "../uploads/" . $imageName;

    move_uploaded_file($tmpName, $uploadPath);

    // save relative path in DB
    $imagePath = "uploads/" . $imageName;
    // 🔥 IMAGE UPLOAD END

    // ✅ INSERT INTO DATABASE
    $stmt = $conn->prepare("INSERT INTO products (name, price, image) VALUES (?, ?, ?)");
    $stmt->bind_param("sds", $name, $price, $imagePath);
    $stmt->execute();

    echo "Product added successfully!";
}
?>


<!DOCTYPE html>
<html>
<head>
    <title>Add Product</title>

    <style>
 /* ✅ Reset & Fix Stretching */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

/* ✅ Page Background */
body {
    font-family: Arial, sans-serif;
    background: linear-gradient(to right, #f8f9fa, #e0eafc);

    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;

    min-height: 100vh;
}
/* ✅ Top Heading */
.page-title {
    text-align: center;
    font-size: 28px;
    margin-top: 30px;
    font-weight: bold;
    color: #333;
}

/* ✅ Form Container */
.container {
    background: white;
    padding: 25px;
    border-radius: 12px;
    width: 320px;
    margin: 40px auto;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
}

/* ✅ Inputs & Dropdown */
input,
select {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
    border-radius: 8px;
    border: 1px solid #ccc;
    font-size: 14px;
    transition: 0.3s;
}

/* ✅ Focus Effect */
input:focus,
select:focus {
    border-color: #6c63ff;
    outline: none;
}

/* ✅ Button */
button {
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    background: #6c63ff;
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s;
}

/* ✅ Button Hover */
button:hover {
    background: #574fd6;
}

/* ✅ Success Message */
.success {
    color: green;
    text-align: center;
    margin-bottom: 10px;
}

/* ✅ Bottom Link Container */
.back-link {
    text-align: center;
    margin-bottom: 30px;
}

/* ✅ Back Link Styling */
.back-link a {
    text-decoration: none;
    color: #6c63ff;
    font-weight: bold;
}

.back-link a:hover {
    text-decoration: underline;
}
    </style>

</head>
<body>


<h2>Add Product</h2>
<div class="container">
<form method="POST" enctype="multipart/form-data">
    <input type="text" name="name" placeholder="Product Name" required><br><br>

    <input type="number" step="0.01" name="price" placeholder="Price" required><br><br>

    <!-- ✅ CATEGORY DROPDOWN -->
    <select name="category" required>
        <option value="">Select Category</option>
        <option value="perfume">Perfume</option>
        <option value="skincare">Skincare</option>
        <option value="makeup">Makeup</option>
        <option value="haircare">Haircare</option>
    </select>

    <input type="file" name="image" required><br><br>

    <button type="submit">Add Product</button>
</form>

<br>
<a href="../admin/admin_dashboard.php">⬅ Back to Dashboard</a>
</div>
</body>
</html>