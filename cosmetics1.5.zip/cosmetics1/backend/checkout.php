<?php
session_start();
$conn = new mysqli("localhost","root","","cosmetics_db");

if (!isset($_SESSION['user_id'])) {
    header("Location: login.html");
    exit();
}

$user_id = $_SESSION['user_id'];

// get user info
$result = $conn->query("SELECT phone_number, address FROM users WHERE id = $user_id");
$user = $result->fetch_assoc();

// HANDLE FORM SUBMIT
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $phone = $_POST['phone'];
    $address = $_POST['address'];

    // update user info
    $conn->query("
        UPDATE users 
        SET phone='$phone', address='$address' 
        WHERE id=$user_id
    ");

    // calculate total (example: from cart table)
    $cart = $conn->query("
        SELECT c.*, p.price 
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = $user_id
    ");

    $total = 0;
    while($item = $cart->fetch_assoc()){
        $total += $item['price'] * $item['quantity'];
    }

    // insert order
    $conn->query("
        INSERT INTO orders (user_id, total) 
        VALUES ($user_id, $total)
    ");

    $order_id = $conn->insert_id;

    // insert order items
    $cart = $conn->query("
        SELECT c.*, p.price 
        FROM cart c 
        JOIN products p ON c.product_id = p.id 
        WHERE c.user_id = $user_id
    ");

    while($item = $cart->fetch_assoc()){
        $conn->query("
            INSERT INTO order_items (order_id, product_id, quantity, price)
            VALUES ($order_id, {$item['product_id']}, {$item['quantity']}, {$item['price']})
        ");
    }

    // clear cart
    $conn->query("DELETE FROM cart WHERE user_id = $user_id");

    echo "<h2>Order Placed Successfully!</h2>";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Checkout</title>
<style>
body {
    font-family: Arial;
    background: #f4f4f4;
    padding: 40px;
}

.container {
    background: white;
    padding: 20px;
    width: 400px;
    margin: auto;
    border-radius: 10px;
}

input, textarea {
    width: 100%;
    padding: 10px;
    margin: 10px 0;
}

button {
    background: green;
    color: white;
    padding: 10px;
    border: none;
    width: 100%;
}
</style>
</head>

<body>

<div class="container">
<h2>Checkout</h2>

<form method="POST">

    <label>Phone Number</label>
    <input type="text" name="phone" required 
        value="<?= $user['phone'] ?>">

    <label>Address</label>
    <textarea name="address" required><?= $user['address'] ?></textarea>

    <button type="submit">Place Order</button>

</form>
</div>

</body>
</html>