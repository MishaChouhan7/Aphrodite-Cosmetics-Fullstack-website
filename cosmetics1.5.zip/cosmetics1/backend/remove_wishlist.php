<?php
include("../db.php");

$id = $_GET['id'];

$conn->query("DELETE FROM wishlist WHERE id=$id");

header("Location: ../wishlist.php");
exit();
?>