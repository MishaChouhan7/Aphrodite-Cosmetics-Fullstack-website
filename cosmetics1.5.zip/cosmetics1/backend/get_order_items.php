<?php
include("../db.php");

$order_id = $_GET['id'];

$result = $conn->query("
    SELECT order_items.quantity, products.name AS product_name, products.price 
    FROM order_items 
    JOIN products ON order_items.product_id = products.id
    WHERE order_items.order_id = '$order_id'
");

$data = [];

while($row = $result->fetch_assoc()){
    $data[] = $row;
}

echo json_encode($data);
?>