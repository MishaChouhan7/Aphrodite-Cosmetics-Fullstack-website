<?php
session_start();
include "db.php";

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if (!isset($_SESSION['user'])) {
    echo "login_required";
    exit;
}



// GET JSON DATA
$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data['cart'])) {
    echo "invalid_cart_data";
    exit;
}

$cart = $data['cart'];

if (!is_array($cart) || count($cart) === 0) {
    echo "empty_cart";
    exit;
}

$user_email = $_SESSION['user']['email'];

// GET USER ID
$stmt_user = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt_user->bind_param("s", $user_email);
$stmt_user->execute();
$result = $stmt_user->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "user_not_found";
    exit;
}

$user_id = (int)$user['id'];

$total = 0;

// CALCULATE TOTAL
foreach ($cart as $item) {
    if (!isset($item['price'], $item['quantity'])) continue;

    $total += (float)$item['price'] * (int)$item['quantity'];
}

if ($total <= 0) {
    echo "invalid_total";
    exit;
}

// INSERT ORDER
$stmt = $conn->prepare("INSERT INTO orders (user_id, total) VALUES (?, ?)");
$stmt->bind_param("id", $user_id, $total);
$stmt->execute();

$order_id = $stmt->insert_id;

// INSERT ORDER ITEMS
$stmt2 = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)");

foreach ($cart as $index => $item) {

    if (!is_array($item)) {
        echo "Invalid item at index: $index";
        print_r($item);
        exit;
    }

    if (!isset($item['id'], $item['quantity'])) {
        echo "Missing data at index: $index";
        print_r($item);
        exit;
    }

    $product_id = (int)$item['id'];
    $qty = (int)$item['quantity'];

    $stmt2->bind_param("iii", $order_id, $product_id, $qty);
    $stmt2->execute();
}

echo "success";
?>