<?php
session_start();
include("../db.php");

$id = $_GET['id'];

// get item
$result = $conn->query("SELECT * FROM wishlist WHERE id=$id");
$item = $result->fetch_assoc();

// insert into cart table
$conn->query("INSERT INTO cart (user_id, product_name, price) 
VALUES ('{$item['user_id']}', '{$item['product_name']}', '{$item['price']}')");

// remove from wishlist
$conn->query("DELETE FROM wishlist WHERE id=$id");

header("Location: ../wishlist.php");
exit();
?>