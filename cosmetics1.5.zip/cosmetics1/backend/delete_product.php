<?php
session_start();

if (!isset($_SESSION['admin'])) {
    echo "Access denied";
    exit;
}

$conn = new mysqli("localhost", "root", "", "cosmetics_db");

$id = $_GET['id'];

$conn->query("DELETE FROM products WHERE id=$id");

header("Location: ../admin/admin_dashboard.php");
?>