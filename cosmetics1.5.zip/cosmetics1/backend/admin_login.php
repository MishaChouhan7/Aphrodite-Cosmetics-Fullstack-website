<?php
session_start();

$email = $_POST['email'];
$password = $_POST['password'];

if ($email === "admin@gmail.com" && $password === "Admin@123") {
    $_SESSION['admin'] = true;
    echo "success";
} else {
    echo "error";
}
?>