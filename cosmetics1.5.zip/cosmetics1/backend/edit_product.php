<?php
session_start();

if (!isset($_SESSION['admin'])) {
    echo "Access denied";
    exit;
}

$conn = new mysqli("localhost", "root", "", "cosmetics_db");

$id = $_GET['id'];

$result = $conn->query("SELECT * FROM products WHERE id=$id");
$product = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $image = $_POST['image'];

    $stmt = $conn->prepare("UPDATE products SET name=?, price=?, image=? WHERE id=?");
    $stmt->bind_param("sdsi", $name, $price, $image, $id);
    $stmt->execute();

    echo "Updated successfully <br><a href='../admin/admin_dashboard.php'>Go Back</a>";
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <style>
 body {
    font-family: Arial, sans-serif;
    background: linear-gradient(135deg, #f8e8ee, #e3f2fd);
    margin: 0;
    padding: 0;
}

/* Heading */
h2 {
    text-align: center;
    margin-top: 30px;
    color: #333;
}

/* Form box */
.form-container {
    background: #ffffff;
    padding: 25px;
    border-radius: 10px;
    width: 350px;
    margin: 20px auto;
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

/* Labels */
label {
    display: block;
    text-align: left;
    margin-left: 30px;
    font-size: 14px;
    color: #555;
}

/* Inputs + dropdown */
input, select {
    width: 85%;
    max-width: 280px;
    padding: 10px;
    margin: 8px auto 15px auto;
    display: block;
    border: 1px solid #ccc;
    border-radius: 6px;
    font-size: 14px;
    transition: 0.3s;
}

/* Focus effect */
input:focus, select:focus {
    border-color: #ff6f91;
    outline: none;
    box-shadow: 0 0 5px rgba(255,111,145,0.4);
}

/* Button */
button {
    width: 85%;
    max-width: 280px;
    padding: 10px;
    background: #ff6f91;
    border: none;
    color: white;
    font-size: 15px;
    border-radius: 6px;
    cursor: pointer;
    display: block;
    margin: 10px auto;
    transition: 0.3s;
}

/* Button hover */
button:hover {
    background: #ff3d6d;
}
    </style>
</head>
<body>
<h2>Edit Product</h2>

<form method="POST">
    <input type="text" name="name" value="<?php echo $product['name']; ?>"><br><br>
    <input type="number" step="0.01" name="price" value="<?php echo $product['price']; ?>"><br><br>
    <input type="text" name="image" value="<?php echo $product['image']; ?>"><br><br>
    <!-- CATEGORY DROPDOWN -->
        <select name="category" required>
            <option value="">Select Category</option>
            <option value="perfume" <?php if($product['category']=="perfume") echo "selected"; ?>>Perfume</option>
            <option value="skincare" <?php if($product['category']=="skincare") echo "selected"; ?>>Skincare</option>
            <option value="makeup" <?php if($product['category']=="makeup") echo "selected"; ?>>Makeup</option>
            <option value="haircare" <?php if($product['category']=="haircare") echo "selected"; ?>>Haircare</option>
        </select>
    <button type="submit">Update</button>
</form>