<?php
session_start();
include("../db.php");

if(!isset($_SESSION['user_id'])){
    echo "not_logged_in";
    exit();
}

$user_id = $_SESSION['user_id'];

if(!isset($_POST['id']) || !isset($_POST['price'])){
    echo "missing_data";
    exit();
}

$product_id = $_POST['id'];
$price = $_POST['price'];

$check = $conn->query("SELECT * FROM cart WHERE user_id='$user_id' AND product_id='$product_id'");

if($check->num_rows > 0){
    $conn->query("UPDATE cart SET quantity = quantity + 1 WHERE user_id='$user_id' AND product_id='$product_id'");
} else {
    $conn->query("INSERT INTO cart (user_id, product_id, price, quantity)
                  VALUES ('$user_id','$product_id','$price',1)");
}

echo "success";
?>