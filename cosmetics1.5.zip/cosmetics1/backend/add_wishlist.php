<?php
session_start();
include("../db.php");

if(!isset($_SESSION['user_id'])){
    echo "not_logged_in";
    exit();
}

$user_id = $_SESSION['user_id'];
$name = $_POST['name'];
$price = $_POST['price'];

// check if exists
$check = $conn->query("SELECT * FROM wishlist WHERE user_id='$user_id' AND product_name='$name'");

if($check->num_rows > 0){
    // remove
    $conn->query("DELETE FROM wishlist WHERE user_id='$user_id' AND product_name='$name'");
    echo "removed";
} else {
    // add
    $conn->query("INSERT INTO wishlist (user_id, product_name, price) VALUES ('$user_id','$name','$price')");
    echo "success";
}
?>