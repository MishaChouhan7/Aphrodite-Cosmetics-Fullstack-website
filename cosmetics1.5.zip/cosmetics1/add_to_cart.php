<?php
session_start();

$conn = new mysqli("localhost","root","","cosmetics_db");

if($conn->connect_error){
    die("Connection failed: " . $conn->connect_error);
}

// ✅ FIXED USER ID (NO RANDOM)
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1;
}
$user_id = $_SESSION['user_id'];

// get product id
if(!isset($_GET['id'])){
    die("Product ID missing");
}

$product_id = $_GET['id'];

// check if already in cart
$check = $conn->query("SELECT * FROM cart WHERE user_id=$user_id AND product_id=$product_id");

if($check->num_rows > 0){
    $conn->query("UPDATE cart SET quantity = quantity + 1 WHERE user_id=$user_id AND product_id=$product_id");
} else {
    $conn->query("INSERT INTO cart (user_id, product_id, quantity) VALUES ($user_id, $product_id, 1)");
}

echo "<script>
alert('🛒 Product added to cart!');
window.location.href='index.php';
</script>";
?>