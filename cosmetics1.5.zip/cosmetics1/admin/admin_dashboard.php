<?php
session_start();

// check admin login
if (!isset($_SESSION['admin'])) {
    header("Location: ../admin.html");
    exit();
}

$conn = new mysqli("localhost", "root", "", "cosmetics_db");

if ($conn->connect_error) {
    die("Connection failed");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        body {
        margin: 0;
        font-family: Arial;
        display: flex;
        background: #f4f4f4;
    }

        .sidebar {
            width: 220px;
            background: #222;
            color: white;
            height: 100vh;
            padding: 20px;
        }

        .sidebar h2 {
            margin-bottom: 20px;
        }

        .sidebar a {
            display: block;
            color: white;
            margin: 10px 0;
            text-decoration: none;
            padding: 8px;
            border-radius: 5px;
        }

        .sidebar a:hover {
            background: #444;
        }

        .content {
            padding: 20px;
            flex: 1;
            background: #f4f4f4;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 10px;
            text-align: left;
        }

        th {
            background: #333;
            color: white;
        }

        .btn {
            padding: 5px 10px;
            text-decoration: none;
            border-radius: 4px;
            color: white;
        }

        .edit { background: blue; }
        .delete { background: red; }
        .add { background: green; display:inline-block; margin-bottom:10px; }
        
        .add-btn {
        display: inline-block;
        background: green;
        color: white;
        padding: 10px;
        margin-bottom: 20px;
        text-decoration: none;
        border-radius: 5px;
    }

    .product-grid {
       display: grid;
      grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
       gap: 20px;
    }

    .product-card {
       background: white;
       padding: 15px;
      border-radius: 10px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      text-align: center;
    }

    .product-img {
        width: 100%;
        height: 150px;
        object-fit: cover;
        border-radius: 8px;
    }

    .product-card h3 {
        margin: 10px 0 5px;
    }

    .product-card p {
        color: #555;
    }

    .actions a {
        margin: 5px;
        text-decoration: none;
        color: white;
        padding: 5px 10px;
        border-radius: 5px;
    }

    .actions a:first-child {
        background: blue;
    }

    .actions a:last-child {
        background: red;
    }
    </style>
</head>

<body>

<div class="sidebar">
    <h2>Admin Panel</h2>
    <a href="?page=products">Manage Products</a>
    <a href="?page=orders">View Orders</a>
    <a href="?page=customers">Customers</a>
    <a href="../backend/logout.php">Logout</a>
</div>

<div class="content">

<?php
$page = isset($_GET['page']) ? $_GET['page'] : 'products';

if ($page == 'products') {

    echo "<h2>Manage Products</h2>";
    echo "<a class='add-btn' href='../backend/add_product.php'>+ Add Product</a>";

    $result = $conn->query("SELECT * FROM products");

    echo "<div class='product-grid'>";

    while($row = $result->fetch_assoc()) {
        echo "<div class='product-card'>
            <img src='../".$row['image']."' class='product-img'>
            <h3>".$row['name']."</h3>
            <p>₹".$row['price']."</p>
            <div class='actions'>
                <a href='../backend/edit_product.php?id=".$row['id']."'>Edit</a>
                <a href='../backend/delete_product.php?id=".$row['id']."' onclick='return confirm(\"Delete?\")'>Delete</a>
            </div>
        </div>";
    }

    echo "</div>";

} elseif ($page == 'orders') {

    echo "<h2>Orders List</h2>";

    $result = $conn->query("SELECT orders.*, users.email FROM orders JOIN users ON orders.user_id = users.id");

    echo "<table>
<tr>
    <th>Order ID</th>
    <th>User</th>
    <th>Total</th>
    <th>Action</th>
</tr>";
?>

<?php while($row = $result->fetch_assoc()) { ?>
<tr>
    <td><?= $row['id'] ?></td>
    <td><?= $row['email'] ?></td>
    <td>₹<?= number_format($row['total'], 2) ?></td>
    <td>
        <button onclick="showOrder(<?= $row['id'] ?>, '<?= $row['email'] ?>', '<?= $row['total'] ?>')">
            View
        </button>
    </td>
</tr>
<?php } ?>

<?php
echo "</table>";

} elseif ($page == 'customers') {

    echo "<h2>Customers</h2>";

    $result = $conn->query("SELECT id, name, email, phone_number FROM users WHERE role='user'");

    echo "<table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Phone No</th>
        </tr>";

    while($row = $result->fetch_assoc()) {
        echo "<tr>
            <td>".$row['id']."</td>
            <td>".$row['name']."</td>
            <td>".$row['email']."</td>
            <td>".$row['phone_number']."</td>
        </tr>";
    }

    echo "</table>";
}
?>

</div>

<!-- ORDER/CUSTOMER MODAL -->
<div id="orderModal" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.6);">
    
    <div style="background:white; width:500px; margin:100px auto; padding:20px; border-radius:10px;">
        
        <h3 id="modalTitle">Details</h3>

        <div id="modalContent"></div>

        <button onclick="closeModal()">Close</button>
    </div>
</div>

<script>
function showOrder(id, user, total) {
    let header = `<p><b>Order ID:</b> ${id}</p>
                  <p><b>User:</b> ${user}</p>
                  <p><b>Total:</b> ₹${total}</p>
                  <h4>Products:</h4>`;

    fetch("../backend/get_order_items.php?id=" + id)
    .then(res => res.json())
    .then(data => {
        let html = header;
        data.forEach(item => {
            html += `<p>${item.product_name} (₹${item.price}) × ${item.quantity}</p>`;
        });
        document.getElementById("modalContent").innerHTML = html;
    });

    document.getElementById("modalTitle").innerText = "Order Details";
    document.getElementById("orderModal").style.display = "block";
}

function viewCustomer(id) {
    fetch("../backend/get_customer.php?id=" + id)
    .then(res => res.text())
    .then(data => {
        document.getElementById("modalTitle").innerText = "Customer Details";
        document.getElementById("modalContent").innerHTML = data;
        document.getElementById("orderModal").style.display = "block";
    });
}

function closeModal() {
    document.getElementById("orderModal").style.display = "none";
}
</script>
</body>
</html>