function getUser() {
  let user = localStorage.getItem("user");
  return user ? user.trim().toLowerCase() : null;
}

const user = getUser();

if (!user) {
  alert("Please login first!");
  window.location.href = "login.html";
}

const cartKey = "cart_" + user;

function loadCart() {
  try {
    return JSON.parse(localStorage.getItem(cartKey)) || [];
  } catch (e) {
    return [];
  }
}

let cart = loadCart();

function saveCart() {
  localStorage.setItem(cartKey, JSON.stringify(cart));
  renderCart();
}

function renderCart() {
  const container = document.getElementById("cart-items");
  const totalEl = document.getElementById("cart-total");

  if (!container || !totalEl) return;

  container.innerHTML = "";

  if (cart.length === 0) {
    container.innerHTML = "<p>Your cart is empty 🛒</p>";
    totalEl.innerText = 0;
    return;
  }

  let total = 0;

  cart.forEach((item, index) => {
    total += item.price * item.quantity;

    const div = document.createElement("div");
    div.classList.add("cart-item");

    div.innerHTML = `
      <div style="flex:1;">
        <h4>${item.name}</h4>
        <p>₹${item.price}</p>
      </div>

      <div class="cart-controls">
        <button onclick="decreaseQty(${index})">-</button>
        <span>${item.quantity}</span>
        <button onclick="increaseQty(${index})">+</button>
      </div>

      <button class="remove-btn" onclick="removeItem(${index})">
        Remove
      </button>
    `;

    container.appendChild(div);
  });

  totalEl.innerText = total;
}

function increaseQty(i) {
  cart[i].quantity++;
  saveCart();
}

function decreaseQty(i) {
  if (cart[i].quantity > 1) {
    cart[i].quantity--;
  } else {
    cart.splice(i, 1);
  }
  saveCart();
}

function removeItem(i) {
  cart.splice(i, 1);
  saveCart();
}

function checkout() {
  if (cart.length === 0) {
    alert("Cart is empty!");
    return;
  }

  fetch("backend/place_order.php", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ cart }),
    credentials: "include"
  })
  .then(res => res.text())
  .then(data => {
    if (data.trim() === "success") {
      alert("Order placed!");
      cart = [];
      saveCart();
    } else {
      alert("Error: " + data);
    }
  });
}

document.addEventListener("DOMContentLoaded", renderCart);